package parrots;

import java.util.ArrayList;
import java.util.List;

public class Cage {
    public String name;
    public int capacity;
    public List<Parrot> data ;

    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public String getName() {
        return this.name;
    }

    public int getCapacity() {
        return this.capacity;
    }
    public void add(Parrot parrot){
        if (this.capacity > data.size()){
            data.add(parrot);
        }
    }
    public boolean remove(String name){
        boolean isThere = false;
        for (Parrot p: data) {
            if (p.getName().equals(name)){
                data.remove(p);
                isThere = true;
                return isThere;
            }
        }
        return isThere;
    }
public Parrot sellParrot(String name){
        Parrot parrot = null;
    for (Parrot p:data) {
        if (p.getName().equals(name)){
            p.setAvailable(false);
            parrot = p;
        }
    }
    return parrot;
}
public List<Parrot> sellParrotBySpecies(String species){
        List<Parrot> sellParrot = new ArrayList<>();
    for (Parrot p:data) {
        if (p.getSpecies().equals(species)){
            p.setAvailable(false);
            sellParrot.add(p);
        }
    }
    return sellParrot;
}
public Integer count(){
        return data.size();
}
public String report(){
        StringBuilder sb = new StringBuilder();
        sb.append("Parrots available at ").append(this.name).append(":").append(System.lineSeparator());
    for (Parrot p:data) {
        if (p.isAvailable()){
            sb.append(p).append(System.lineSeparator());
        }
    }
    return sb.toString();
}
}
